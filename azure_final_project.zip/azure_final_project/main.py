#!/home/baskar/venv-python310/bin/python
import os
import json
import tempfile
import subprocess
import ansible_runner
import re

curdir = os.getcwd()

ipnumber = ''
ssh_user = "linuxuser"
ssh_private_key_file =  os.path.join(curdir,"linuxkey.pem")


tfinit = subprocess.Popen(['terraform','init','--upgrade'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
output,errors = tfinit.communicate()
rc = tfinit.returncode
print(output.decode('utf-8'))
if rc == 0:
    tfplan = subprocess.Popen(['terraform','plan',"-out=output"],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, errors = tfplan.communicate()
    rc = tfplan.returncode
    print(output.decode('utf-8'))
    if rc == 0:
        tfapply = subprocess.Popen(['terraform','apply',"output"],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output,errors =  tfapply.communicate()
        content = output.decode("utf-8")
        print(content)
        sobj = re.search(r'public_ip_address\s*=\D*(\d+\.\d+\.\d+\.\d+)',content)
        if sobj:
            ipnumber = sobj.group(1)
            os.chmod("linuxkey.pem",0o400)
    else:
        print(errors.decode("utf-8"))
#p = subprocess.Popen(['terraform','plan','-destroy',"-out=output"],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def run(ip_number,ssh_user,ssh_private_key_file):

    # create an Ansible playbook as a native Python dict object. Currently
    # ansible-runner does not validate the playbook structure so it needs to be
    # correct when passed in otherwise ansible will fail.
    playbook = {
        'hosts': 'azurehost',
        'roles': [{
            'name': 'webserver',
            'function': 'clear_sessions'
        }]
    }
    roles_path = [os.path.join(curdir,"roles")]

    # this addes the path endpoints that allow ansible work be run from a
    # virtualenv when ansible-runner calls ansible.  setting the path is not
    # necessary if ansible is installed in system python.
    path = '/home/sprygada/Workspaces/ansible/bin:/home/sprygada/.virtualenvs/ansible/bin:'
    path += os.environ.get('PATH', '')


    # setup various environment vars to be set prior to starting the ansible
    # executable.  this step is completely optional depending on what needs to
    # be done.
    envvars = {
        'PATH': path,
        'ANSIBLE_ROLES_PATH': './roles:',
        'ANSIBLE_INVENTORY_PLUGIN_EXTS': '.json'
    }

    # this is the inventory that ansible will use when the playbook is run.
    # this inventory is implemented by the yaml inventory plugin which is
    # documented below
    # https://docs.ansible.com/ansible/latest/plugins/inventory/yaml.html
    hosts = {
        'hosts': {
            'azurehost': {
                'ansible_ssh_host': ip_number
            },
        },
        'vars': {
            'ansible_python_interpreter': 'python3',
            'ansible_connection': 'ssh',
            'ansible_ssh_user': ssh_user,
            'ansible_ssh_private_key_file': ssh_private_key_file,
            'ansible_ssh_common_args': '-o StrictHostKeyChecking=no'
        },
        
    }

    # this will pass any extra vars to the ansible command line (same as using
    # the -e switch when running ansible manually)
    extravars = {
        #'ansible_connection': 'network_cli'
    }

    # builds the set of kwargs to pass to ansible-runner.  not in this example
    # is the use of passwords, ssh_key both of which are supported.  see
    # https://github.com/ansible/ansible-runner for more details.
    kwargs = {
        'roles_path': roles_path,
        'envvars': envvars,
        'playbook': [playbook],
        'inventory': {'all': hosts},
        'extravars': extravars
    }

    result = ansible_runner.run(**kwargs)

    stdout = result.stdout.read()
    events = list(result.events)
    stats = result.stats

    print(json.dumps(stats, indent=4))

run(ipnumber,ssh_user,ssh_private_key_file)
